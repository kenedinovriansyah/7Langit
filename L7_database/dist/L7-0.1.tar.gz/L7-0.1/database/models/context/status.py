

class Status:
    active = 0
    inactive = 1
    choice = ((active, "Active"), (inactive, "Inactive"))